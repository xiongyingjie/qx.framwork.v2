﻿
function charge() {
    confirmPay($("#num").val());
}