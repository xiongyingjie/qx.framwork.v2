﻿render([

input("用户id", "userid", "请输入用户id", "3", "请输入姓名"),
input("姓名", "name", "请输入姓名", "3", "请输入姓名"),
input("密码", "psw", "请输入密码", "3", "请输入姓名"),
], "*","/home/bind");