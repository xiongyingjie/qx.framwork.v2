﻿render([
    group([
showInput('按钮ID', 'button-button_id', '', '4'),
showInput('菜单ID', 'button-menu_id', '', '4'),
showInput('按钮名称', 'button-name', '', '4'),
showInput('备注', 'button-note', '', '4'),
showInput('按钮值', 'button-value', '', '4')
],'标题')],'','sys.core.button@find&id='+q.id,'','详情');